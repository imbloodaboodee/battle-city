package entities;

public enum BulletType {
    NORMAL, RICOCHET, EXPLOSIVE, RAPID
}
